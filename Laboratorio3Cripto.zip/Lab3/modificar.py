
txt = "rockyou.txt"
dic = "rockyou_mod.dic"

def modificar_string(password):
    if len(password) > 0:
        if password[0].isalpha():
            return password[0].upper() + password[1:] + "0"
        else:
            return None

lineas_modificadas = []
with open(txt, "r", errors="ignore") as archivo:
    lineas = archivo.readlines()
    for linea in lineas:
        linea = linea.strip()
        modificado = modificar_string(linea)
        if modificado:
            lineas_modificadas.append(modificado)
with open(dic, "w") as archivo:
    archivo.write("\n".join(lineas_modificadas))
    cant = len(lineas_modificadas)
print("-------------")
print("Cantidad de passwords en rockyou_mod.dic: ", cant)
print("-------------")